package de.codeboje.springbootbook.logging;

public interface SBBLoggingConstants {
    public static final String REQUEST_UUID_HEADER = "SBBRequestUUID";
}
